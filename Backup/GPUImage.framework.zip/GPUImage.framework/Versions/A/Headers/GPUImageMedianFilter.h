#import "GPUImage3x3TextureSamplingFilter.h"

@interface GPUImageMedianFilter : GPUImage3x3TextureSamplingFilter

@end
