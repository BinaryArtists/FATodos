#import "GPUImageTwoInputFilter.h"

@interface GPUImageLinearBurnBlendFilter : GPUImageTwoInputFilter

@end
